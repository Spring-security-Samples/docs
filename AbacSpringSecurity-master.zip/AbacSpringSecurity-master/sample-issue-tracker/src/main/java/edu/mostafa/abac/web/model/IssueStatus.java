package edu.mostafa.abac.web.model;

public enum IssueStatus {
	NEW, ASSIGNED, COMPLETED
}
