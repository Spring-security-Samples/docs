package edu.mostafa.abac.web.model;

public enum IssueType {
	TASK, BUG
}
