package edu.mostafa.abac.web.model;

public enum UserRole {
	ADMIN, PM, DEVELOPER, TESTER
}
