package edu.mostafa.abac.config;

import org.springframework.security.web.context.AbstractSecurityWebApplicationInitializer;

public class AbacSecurityInitializer extends AbstractSecurityWebApplicationInitializer {
}
