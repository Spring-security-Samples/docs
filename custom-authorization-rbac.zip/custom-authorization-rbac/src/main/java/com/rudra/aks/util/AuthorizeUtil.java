package com.rudra.aks.util;

public interface AuthorizeUtil {

	boolean isAuthorize(Object principal, int userid);
}
