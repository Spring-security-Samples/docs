package com.rudra.aks.service;

import com.rudra.aks.model.Privilege;

public interface PrivilegeService {

	boolean 	addPrivilege(Privilege privileges);
}
