package com.rudra.aks.constants;

public class Constants {

	public static final String INDEX_PAGE = "indexjsp";
	public static final String HOME_PAGE = "welcome";
	public static final String REGISTER_FORM = "registeruser";
	public static final String UPDATE_FORM = "updateuser";
	public static final String ROLE_FORM =  "addroles";
	public static final String ACCESSDENIED_PAGE = "accessdenied";
	public static final String USERSLIST_PAGE = "userslist";
}
